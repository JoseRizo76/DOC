config = {
    'secretkey' :'snackvendigmachine2023',
    'hashedpass' : 'pbkdf2:sha256',
    'databasename': 'server.db',
    'sesionpass': "SVM2024",
    'tiposesion' : 'filesystem'
}

vendedor = {
  'USUARIO': "SVM",
  'PASSWORD': "SVM2024" 
}
